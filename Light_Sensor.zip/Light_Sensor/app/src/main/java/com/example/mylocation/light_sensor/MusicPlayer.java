package com.example.mylocation.light_sensor;

import android.app.Service;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class MusicPlayer extends AppCompatActivity implements SensorEventListener{

    MediaPlayer player;
    private double value;
    private float last_time = 0;
    private double pre_value = 0;
    private float NS2S = 1.0f/1000000000.0f;

    private Handler hander = new Handler();
    private String pre_status="";
    private double interval;

    SensorManager sensorManager;
    Sensor sensor;
    SensorEventListener sensorEventListener;

    private int count = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_player);

        sensorManager = (SensorManager) getSystemService(Service.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

      //  checkGesture();
    }

//    private void checkGesture() {
//        hander.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                sensorEventListener = new SensorEventListener() {
//                    @Override
//                    public void onSensorChanged(SensorEvent event) {
//                        if (event.sensor.getType() == Sensor.TYPE_LIGHT){
//                            value = event.values[0];
//                            if(pre_value == 0){
//                                pre_value = (float) value;
//                            }else if (pre_value - value>20000){
//                                pre_value = (float) value;
//                                if(last_time ==0){
//                                    last_time=event.timestamp;
//                                }
//                            }else if (value - pre_value>20000){
//                                pre_value = (float) value;
//                                count += 1;
//                                Toast.makeText(MusicPlayer.this,"Works",Toast.LENGTH_SHORT).show();
//                            }
//                            if(last_time !=0 && (event.timestamp-last_time)*NS2S>5){
//                                last_time = 0;
//                                if(count == 1){
//                                    play_music();
//                                    Toast.makeText(MusicPlayer.this,"Music Play",Toast.LENGTH_SHORT).show();
//                                }else if(count ==2){
//                                    pause_music();
//                                    Toast.makeText(MusicPlayer.this,"Music Pause",Toast.LENGTH_SHORT).show();
//                                }else if(count == 3){
//                                    onStop();
//                                    Toast.makeText(MusicPlayer.this,"Music Stop",Toast.LENGTH_SHORT).show();
//                                }
//                                //function
//                                count = 0;
//                            }
//                        }
//                    }
//                    @Override
//                    public void onAccuracyChanged(Sensor sensor, int accuracy) {
//
//                    }
//                };
//           //     maniputation();
//            }
//
//        },1000);
//
//    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_FASTEST);
    }


    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }


    public void play(View v) {
        if (player == null) {
            player = MediaPlayer.create(this, R.raw.music_material);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    stopPlayer();
                }
            });
//            Toast.makeText(MusicPlayer.this,"Music Play",Toast.LENGTH_SHORT).show();
        }

        player.start();
    }

    public void play_music() {
        if (player == null) {
            player = MediaPlayer.create(this, R.raw.music_material);
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    stopPlayer();
                }
            });
        }

        player.start();
    }

    public void pause(View v) {
        if (player != null) {
            player.pause();
        }
    }

    public void pause_music() {
        if (player != null) {
            player.pause();
        }
    }

    public void stop(View v) {
        stopPlayer();
    }

    private void stopPlayer() {
        if (player != null) {
            player.release();
            player = null;
            Toast.makeText(this, "MediaPlayer released", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopPlayer();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_LIGHT){
        //    Toast.makeText(MusicPlayer.this,"Works",Toast.LENGTH_SHORT).show();
            value = event.values[0]/10;
            interval = value*0.8;

            if(pre_value == 0){
                pre_value = (float) value;
            }else if (pre_value - value>interval){
                pre_value = (float) value;
                if(last_time ==0){
                    last_time=event.timestamp;
                    pre_status = "down";
                }
            }else if (value - pre_value>interval){
                pre_value = (float) value;
                count += 1;
                pre_status="";
        //        Toast.makeText(MusicPlayer.this,"Works",Toast.LENGTH_SHORT).show();
            }
            if(last_time !=0 && (event.timestamp-last_time)*NS2S>5){
                last_time = 0;
               //Toast.makeText(MusicPlayer.this,"Count"+count,Toast.LENGTH_SHORT).show();
                if(count == 1){
                    play_music();
                    Toast.makeText(MusicPlayer.this,"Music Play",Toast.LENGTH_SHORT).show();
                }else if(count ==2){
                    pause_music();
                    Toast.makeText(MusicPlayer.this,"Music Pause",Toast.LENGTH_SHORT).show();
                }else if(count == 3){
                    onStop();
                    Toast.makeText(MusicPlayer.this,"Music Stop",Toast.LENGTH_SHORT).show();
                }
                //function
                count = 0;
            }
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
