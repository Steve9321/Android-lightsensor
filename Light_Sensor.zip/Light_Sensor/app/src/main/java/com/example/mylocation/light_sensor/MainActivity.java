package com.example.mylocation.light_sensor;

import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    private Handler mhander = new Handler();
    private LineGraphSeries<DataPoint> series;
    private double lastXPoint = 1;
    private double value;
    private float last_time = 0;
    private double pre_value = 0;
    private float NS2S = 1.0f/1000000000.0f;
    private int count = 0;
    private String pre_status = "";
    private double interval;
    private int max_double = 200;
    GraphView graph;
    private float check_time;
    //   private Random rnd = new Random();

    TextView textView, textNum;
    Button btn;

    SensorManager sensorManager;
    Sensor sensor;

    private final int FIVE_SECONDS = 5000;
    private Handler handler = new Handler();
    // handler for gesture count

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);
        textNum = (TextView) findViewById(R.id.countnumber);
        btn = (Button) findViewById(R.id.jump);

        sensorManager = (SensorManager) getSystemService(Service.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        graph = (GraphView) findViewById(R.id.graph);
        series = new LineGraphSeries<>(new DataPoint[]{
//                new DataPoint(0,1),
        });
        graph.addSeries(series);
        graph.getViewport().setMinX(10);
        graph.getViewport().setMaxX(20);
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setScalable(true);
        graph.getViewport().setDrawBorder(true);
        graph.getViewport().setMaxY(max_double);
        GridLabelRenderer glr = graph.getGridLabelRenderer();
        graph.getViewport().setYAxisBoundsManual(true);
        glr.setPadding(120);

        addRandomData();
//        scheduleCount();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,MusicPlayer.class);
                startActivity(intent);
            }
        });

    }

    private void addRandomData(){//live time line graph show
        mhander.postDelayed(new Runnable() {
            @Override
            public void run() {
                lastXPoint++;
                series.appendData(new DataPoint(lastXPoint,value),true,25);
                addRandomData();
            }
        },1000);
    }

//
//    public void scheduleCount() { //count the gesture number in 5 seconds
//        handler.postDelayed(new Runnable() {
//            public void run() {
//
//                countNumber();          // this method will contain your almost-finished HTTP calls
//                handler.postDelayed(this, FIVE_SECONDS);
//                textNum.setText("There are " + number + " times");
//     //           scheduleCount();
//     //           number = 0;
//            }
//        }, 5000);
//
//
//    }
//
//    private void countNumber() {
//
//        if (value==0){
//            number++;
//        }
//    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_LIGHT){
            textView.setText("" + event.values[0]);

            value = event.values[0]/10;
            interval = value*0.8;
//            if(value>50){
//                interval = 80;
//            }else if(value < 20){
//                interval = 10;
//            }else{
//                interval = 40;
//            }
            if(value > max_double){
                graph.getViewport().setMaxY(value*1.1);
                max_double = (int)value;
            }
            if(pre_value == 0){
                pre_value = (float) value;
            }else if (pre_value - value>interval){
                pre_value = (float) value;
                if(last_time ==0){
                    last_time=event.timestamp;
                    pre_status = "down";
                }
            }else if (value - pre_value>interval){
                pre_value = (float) value;
                count += 1;
            }
            if(last_time !=0 && (event.timestamp-last_time)*NS2S>5){
                last_time = 0;
               // last_time = event.timestamp;
                if (count==1){
                    textNum.setText("There is only" + count + " time");
                } else if (count==0){
                    textNum.setText("There is 0");
                }else{
                    textNum.setText("There are " + count + " times");
                }
                //function
                count = 0;
                pre_status="";
                check_time = event.timestamp;
//            }else if (count>0  && (event.timestamp-last_time)*NS2S>5){
//                count--;
//                if (count==1){
//                    textNum.setText("There is only" + count + " time");
//                } else if (count==0){
//                    textNum.setText("There is 0");
//                }else{
//                    textNum.setText("There are " + count + " times");
//                }
//                last_time = event.timestamp;

            }else if(last_time ==0 && count==0 && (event.timestamp-check_time)*NS2S>5 && check_time!=0){
                check_time = 0;
                textNum.setText("There is 0");
            }

//            textNum.setText("There are " + number + " times");
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
